<?php defined('BASEPATH') OR exit('No direct script access allowed');

class All extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    public function member($member = 0)
    {
        // $this->db->where('group_id', $member);
        $dt = $this->db->get('sink_menu');
        $oke = $dt->result();

        return $this->buildTree($oke,0);
    }

    public function buildTree(array &$elements, $parentId = 0)
    {
        $branch = array();

        foreach ($elements as $element) {
            if ($element->parent == $parentId) {
                $children = self::buildTree($elements, $element->id);
                if ($children) {
                    $element->state = 'closed';
                    $element->children = $children;
                }
                $branch[] = $element;
            }
        }
        return $branch;
    }

    
}

/* End of file all.php */
/* Location: ./application/models/all.php */