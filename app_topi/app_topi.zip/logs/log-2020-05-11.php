<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-11 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-11 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-11 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-11 01:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-05-11 02:09:33 --> 404 Page Not Found: 2phpmyadmin/scripts
ERROR - 2020-05-11 02:09:34 --> 404 Page Not Found: PMA/scripts
ERROR - 2020-05-11 02:09:36 --> 404 Page Not Found: PMA2011/scripts
ERROR - 2020-05-11 02:09:37 --> 404 Page Not Found: PMA2012/scripts
ERROR - 2020-05-11 02:09:38 --> 404 Page Not Found: PMA2013/scripts
ERROR - 2020-05-11 02:09:40 --> 404 Page Not Found: PMA2015/scripts
ERROR - 2020-05-11 02:09:42 --> 404 Page Not Found: PMA2016/scripts
ERROR - 2020-05-11 02:09:43 --> 404 Page Not Found: PMA2018/scripts
ERROR - 2020-05-11 02:09:45 --> 404 Page Not Found: SQL/scripts
ERROR - 2020-05-11 02:09:47 --> 404 Page Not Found: _PHPMYADMIN/scripts
ERROR - 2020-05-11 02:09:48 --> 404 Page Not Found: Admin/db
ERROR - 2020-05-11 02:09:49 --> 404 Page Not Found: Admin/mysql
ERROR - 2020-05-11 02:09:50 --> 404 Page Not Found: Admin/pMA
ERROR - 2020-05-11 02:09:52 --> 404 Page Not Found: Admin/phpMyadmin
ERROR - 2020-05-11 02:09:53 --> 404 Page Not Found: Admin/scripts
ERROR - 2020-05-11 02:09:54 --> 404 Page Not Found: Admin/setup.php
ERROR - 2020-05-11 02:09:55 --> 404 Page Not Found: Admin/sql
ERROR - 2020-05-11 02:09:57 --> 404 Page Not Found: Admin/sqladmin
ERROR - 2020-05-11 02:09:58 --> 404 Page Not Found: Admin/sysadmin
ERROR - 2020-05-11 02:10:00 --> 404 Page Not Found: Admin/web
ERROR - 2020-05-11 02:10:02 --> 404 Page Not Found: Administrator/admin
ERROR - 2020-05-11 02:10:03 --> 404 Page Not Found: Administrator/db
ERROR - 2020-05-11 02:10:04 --> 404 Page Not Found: Administrator/pma
ERROR - 2020-05-11 02:10:06 --> 404 Page Not Found: Administrator/web
ERROR - 2020-05-11 02:10:07 --> 404 Page Not Found: Blog/phpmyadmin
ERROR - 2020-05-11 02:10:08 --> 404 Page Not Found: Cpadmin/scripts
ERROR - 2020-05-11 02:10:09 --> 404 Page Not Found: Cpadmindb/scripts
ERROR - 2020-05-11 02:10:12 --> 404 Page Not Found: Cpanelmysql/scripts
ERROR - 2020-05-11 02:10:13 --> 404 Page Not Found: Cpanelphpmyadmin/scripts
ERROR - 2020-05-11 02:10:14 --> 404 Page Not Found: Database/scripts
ERROR - 2020-05-11 02:10:15 --> 404 Page Not Found: Db/db_admin
ERROR - 2020-05-11 02:10:17 --> 404 Page Not Found: Db/dbadmin
ERROR - 2020-05-11 02:10:18 --> 404 Page Not Found: Db/dbweb
ERROR - 2020-05-11 02:10:19 --> 404 Page Not Found: Db/myadmin
ERROR - 2020-05-11 02:10:20 --> 404 Page Not Found: Db/phpMyAdmin_3
ERROR - 2020-05-11 02:10:22 --> 404 Page Not Found: Db/phpmyadmin
ERROR - 2020-05-11 02:10:23 --> 404 Page Not Found: Db/phpmyadmin3
ERROR - 2020-05-11 02:10:24 --> 404 Page Not Found: Db/scripts
ERROR - 2020-05-11 02:10:25 --> 404 Page Not Found: Db/webadmin
ERROR - 2020-05-11 02:10:27 --> 404 Page Not Found: Db/webdb
ERROR - 2020-05-11 02:10:28 --> 404 Page Not Found: Db/websql
ERROR - 2020-05-11 02:10:29 --> 404 Page Not Found: Dbadmin/scripts
ERROR - 2020-05-11 02:10:31 --> 404 Page Not Found: My/scripts
ERROR - 2020-05-11 02:10:32 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-05-11 02:10:34 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-05-11 02:10:36 --> 404 Page Not Found: Myadmin/setup
ERROR - 2020-05-11 02:10:37 --> 404 Page Not Found: Mysql_admin/scripts
ERROR - 2020-05-11 02:10:38 --> 404 Page Not Found: Mysql/admin
ERROR - 2020-05-11 02:10:39 --> 404 Page Not Found: Mysql/db
ERROR - 2020-05-11 02:10:41 --> 404 Page Not Found: Mysql/mysqlmanager
ERROR - 2020-05-11 02:10:43 --> 404 Page Not Found: Mysql/pMA
ERROR - 2020-05-11 02:10:44 --> 404 Page Not Found: Mysql/scripts
ERROR - 2020-05-11 02:10:46 --> 404 Page Not Found: Mysql/sqlmanager
ERROR - 2020-05-11 02:10:47 --> 404 Page Not Found: Mysql/web
ERROR - 2020-05-11 02:10:48 --> 404 Page Not Found: Mysqladmin/scripts
ERROR - 2020-05-11 02:10:50 --> 404 Page Not Found: Mysqlmanager/scripts
ERROR - 2020-05-11 02:10:54 --> 404 Page Not Found: Php_my_admin/scripts
ERROR - 2020-05-11 02:10:55 --> 404 Page Not Found: Php_myadmin/scripts
ERROR - 2020-05-11 02:10:59 --> 404 Page Not Found: PhpLDAPadmin/scripts
ERROR - 2020-05-11 02:11:01 --> 404 Page Not Found: PhpMyAdmi/scripts
ERROR - 2020-05-11 02:11:02 --> 404 Page Not Found: PhpMyAdmin_21000/scripts
ERROR - 2020-05-11 02:11:03 --> 404 Page Not Found: PhpMyAdmin_2100/scripts
ERROR - 2020-05-11 02:11:04 --> 404 Page Not Found: PhpMyAdmin_2111_all_languages/scripts
ERROR - 2020-05-11 02:11:06 --> 404 Page Not Found: PhpMyAdmin_211113/scripts
ERROR - 2020-05-11 02:11:07 --> 404 Page Not Found: PhpMyAdmin_21111/scripts
ERROR - 2020-05-11 02:11:08 --> 404 Page Not Found: PhpMyAdmin_255/index.php
ERROR - 2020-05-11 02:11:10 --> 404 Page Not Found: PhpMyAdmin_255/scripts
ERROR - 2020-05-11 02:11:11 --> 404 Page Not Found: PhpMyAdmin_2/scripts
ERROR - 2020-05-11 02:11:12 --> 404 Page Not Found: PhpMyAdmin_3000_all_languages/scripts
ERROR - 2020-05-11 02:11:14 --> 404 Page Not Found: PhpMyAdmin_3/scripts
ERROR - 2020-05-11 02:11:15 --> 404 Page Not Found: PhpMyAdmin2/setup
ERROR - 2020-05-11 02:11:17 --> 404 Page Not Found: PhpMyAds/scripts
ERROR - 2020-05-11 02:11:18 --> 404 Page Not Found: Phpadmin/scripts
ERROR - 2020-05-11 02:11:20 --> 404 Page Not Found: Phpmanager/scripts
ERROR - 2020-05-11 02:11:21 --> 404 Page Not Found: Phpmy_admin/scripts
ERROR - 2020-05-11 02:11:23 --> 404 Page Not Found: Phpmy/scripts
ERROR - 2020-05-11 02:11:30 --> 404 Page Not Found: Phpmyadmin2/scripts
ERROR - 2020-05-11 02:11:31 --> 404 Page Not Found: Phpmyadmin2011/scripts
ERROR - 2020-05-11 02:11:33 --> 404 Page Not Found: Phpmyadmin2012/scripts
ERROR - 2020-05-11 02:11:34 --> 404 Page Not Found: Phpmyadmin2013/scripts
ERROR - 2020-05-11 02:11:35 --> 404 Page Not Found: Phpmyadmin2014/scripts
ERROR - 2020-05-11 02:11:36 --> 404 Page Not Found: Phpmyadmin2015/scripts
ERROR - 2020-05-11 02:11:38 --> 404 Page Not Found: Phpmyadmin2017/scripts
ERROR - 2020-05-11 02:11:39 --> 404 Page Not Found: Phpmyadmin2018/scripts
ERROR - 2020-05-11 02:11:40 --> 404 Page Not Found: Phpmyadmin3/scripts
ERROR - 2020-05-11 02:11:41 --> 404 Page Not Found: Phpmyadmin4/scripts
ERROR - 2020-05-11 02:11:46 --> 404 Page Not Found: Phpmyadmin6/scripts
ERROR - 2020-05-11 02:11:47 --> 404 Page Not Found: Phpmyadmin7/scripts
ERROR - 2020-05-11 02:11:48 --> 404 Page Not Found: Phppgadmin/scripts
ERROR - 2020-05-11 02:11:50 --> 404 Page Not Found: Phppma/scripts
ERROR - 2020-05-11 02:11:51 --> 404 Page Not Found: Pma2006/scripts
ERROR - 2020-05-11 02:11:52 --> 404 Page Not Found: Pma2007/scripts
ERROR - 2020-05-11 02:11:53 --> 404 Page Not Found: Pma2008/scripts
ERROR - 2020-05-11 02:11:55 --> 404 Page Not Found: Pma2014/scripts
ERROR - 2020-05-11 02:11:56 --> 404 Page Not Found: Pma2017/scripts
ERROR - 2020-05-11 02:11:57 --> 404 Page Not Found: Program/scripts
ERROR - 2020-05-11 02:12:01 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2020-05-11 02:12:03 --> 404 Page Not Found: Setup/index.php
ERROR - 2020-05-11 02:12:04 --> 404 Page Not Found: Shopdb/scripts
ERROR - 2020-05-11 02:12:05 --> 404 Page Not Found: Sql/myadmin
ERROR - 2020-05-11 02:12:07 --> 404 Page Not Found: Sql/php_myadmin
ERROR - 2020-05-11 02:12:08 --> 404 Page Not Found: Sql/phpMyAdmin
ERROR - 2020-05-11 02:12:09 --> 404 Page Not Found: Sql/phpMyAdmin2
ERROR - 2020-05-11 02:12:10 --> 404 Page Not Found: Sql/phpmanager
ERROR - 2020-05-11 02:12:12 --> 404 Page Not Found: Sql/phpmy_admin
ERROR - 2020-05-11 02:12:13 --> 404 Page Not Found: Sql/sql_admin
ERROR - 2020-05-11 02:12:14 --> 404 Page Not Found: Sql/sql
ERROR - 2020-05-11 02:12:16 --> 404 Page Not Found: Sql/sqladmin
ERROR - 2020-05-11 02:12:17 --> 404 Page Not Found: Sql/sqlweb
ERROR - 2020-05-11 02:12:18 --> 404 Page Not Found: Sql/webadmin
ERROR - 2020-05-11 02:12:19 --> 404 Page Not Found: Sql/webdb
ERROR - 2020-05-11 02:12:21 --> 404 Page Not Found: Sql/websql
ERROR - 2020-05-11 02:12:22 --> 404 Page Not Found: Sqladm/scripts
ERROR - 2020-05-11 02:12:24 --> 404 Page Not Found: Sqladmin/scripts
ERROR - 2020-05-11 02:12:26 --> 404 Page Not Found: Sqlmanager/scripts
ERROR - 2020-05-11 02:12:27 --> 404 Page Not Found: Sqlweb/scripts
ERROR - 2020-05-11 02:12:28 --> 404 Page Not Found: Web/phpmyadmin
ERROR - 2020-05-11 02:12:29 --> 404 Page Not Found: Web/scripts
ERROR - 2020-05-11 02:12:31 --> 404 Page Not Found: Webadmin/scripts
ERROR - 2020-05-11 02:12:32 --> 404 Page Not Found: Webdb/scripts
ERROR - 2020-05-11 02:12:33 --> 404 Page Not Found: Websql/scripts
ERROR - 2020-05-11 02:12:35 --> 404 Page Not Found: Xampp/phpmyadmin
ERROR - 2020-05-11 02:12:36 --> 404 Page Not Found: ~/phpmanager
ERROR - 2020-05-11 02:12:37 --> 404 Page Not Found: Phpmy/scripts
ERROR - 2020-05-11 02:12:38 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-05-11 02:12:40 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-11 02:12:41 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-05-11 02:12:42 --> 404 Page Not Found: Phpmy/scripts
ERROR - 2020-05-11 02:12:43 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-11 03:26:55 --> 404 Page Not Found: Assets/theme
ERROR - 2020-05-11 05:14:43 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-11 07:06:20 --> 404 Page Not Found: Manager/html
ERROR - 2020-05-11 09:47:56 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-11 10:59:52 --> Severity: Warning --> oci_connect(): ORA-12170: TNS:Connect timeout occurred C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-11 10:59:53 --> Unable to connect to the database
ERROR - 2020-05-11 11:00:14 --> Severity: Warning --> oci_connect(): ORA-12170: TNS:Connect timeout occurred C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-11 11:00:14 --> Unable to connect to the database
ERROR - 2020-05-11 11:00:14 --> Query error: ORA-12170: TNS:Connect timeout occurred - Invalid query: SELECT * FROM (SELECT inner_query.*, rownum rnum FROM (SELECT "BIODATA_WNI"."NIK", "DATA_KELUARGA"."NO_KK", "BIODATA_WNI"."NAMA_LGKP", TO_CHAR(BIODATA_WNI.TGL_LHR, 'DD-MM-YYYY') as TGL_LHR, "DATA_KELUARGA"."ALAMAT", "DATA_KELUARGA"."DUSUN", "DATA_KELUARGA"."NO_RT", "DATA_KELUARGA"."NO_RW", "DATA_KELUARGA"."NAMA_KEP", "AGAMA_MASTER"."DESCRIP" as "AGAMA", "PDDKN_MASTER"."DESCRIP" AS "PENDIDIKAN", "PKRJN_MASTER"."DESCRIP" AS "PEKERJAAN", "BIODATA_WNI"."JENIS_KLMIN", "SETUP_KEL"."NAMA_KEL"
FROM "BIODATA_WNI"
JOIN "DATA_KELUARGA" ON "BIODATA_WNI"."NO_KK" = "DATA_KELUARGA"."NO_KK"
LEFT JOIN "PDDKN_MASTER" ON "BIODATA_WNI"."PDDK_AKH" = "PDDKN_MASTER"."NO"
LEFT JOIN "PKRJN_MASTER" ON "BIODATA_WNI"."JENIS_PKRJN" = "PKRJN_MASTER"."NO"
LEFT JOIN "AGAMA_MASTER" ON "BIODATA_WNI"."AGAMA" = "AGAMA_MASTER"."NO"
JOIN "SETUP_KEL" ON "DATA_KELUARGA"."NO_KAB" = "SETUP_KEL"."NO_KAB" AND "DATA_KELUARGA"."NO_PROP" = "SETUP_KEL"."NO_PROP" AND "DATA_KELUARGA"."NO_KEC" = "SETUP_KEL"."NO_KEC" AND "DATA_KELUARGA"."NO_KEL" = "SETUP_KEL"."NO_KEL"
WHERE "NIK" = '3576021712910003'
) inner_query WHERE rownum < 2)
ERROR - 2020-05-11 11:00:14 --> Severity: Error --> Call to a member function row_array() on a non-object C:\xampp\htdocs\app_topi\controllers\api\Gayatri.php 50
ERROR - 2020-05-11 11:35:41 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-11 11:38:58 --> 404 Page Not Found: Manager/text
ERROR - 2020-05-11 14:03:52 --> 404 Page Not Found: TP/public
ERROR - 2020-05-11 14:03:53 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-11 14:03:54 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-11 14:03:54 --> 404 Page Not Found: Html/public
ERROR - 2020-05-11 14:03:55 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-11 14:03:56 --> 404 Page Not Found: TP/html
ERROR - 2020-05-11 14:03:57 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-11 14:55:38 --> 404 Page Not Found: Assets/uploads
ERROR - 2020-05-11 14:55:39 --> 404 Page Not Found: Assets/theme
ERROR - 2020-05-11 15:14:47 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-11 18:07:45 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-11 23:50:38 --> 404 Page Not Found: Portal/redlion
