<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-01 00:26:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-01 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-01 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-01 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-01 04:36:44 --> 404 Page Not Found: TP/public
ERROR - 2020-05-01 04:36:45 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-01 04:36:45 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-01 04:36:46 --> 404 Page Not Found: Html/public
ERROR - 2020-05-01 04:36:47 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-01 04:36:48 --> 404 Page Not Found: TP/html
ERROR - 2020-05-01 04:36:50 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-01 07:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-01 09:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-01 12:04:18 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-05-01 14:23:50 --> 404 Page Not Found: TP/public
ERROR - 2020-05-01 14:23:51 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-01 14:23:51 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-01 14:23:51 --> 404 Page Not Found: Html/public
ERROR - 2020-05-01 14:23:52 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-01 14:23:52 --> 404 Page Not Found: TP/html
ERROR - 2020-05-01 14:23:52 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-01 20:22:51 --> 404 Page Not Found: TP/public
ERROR - 2020-05-01 20:22:53 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-01 20:22:53 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-01 20:22:54 --> 404 Page Not Found: Html/public
ERROR - 2020-05-01 20:22:55 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-01 20:22:56 --> 404 Page Not Found: TP/html
ERROR - 2020-05-01 20:22:57 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-01 21:22:32 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-05-01 21:22:32 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-05-01 21:22:33 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-05-01 21:22:34 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-05-01 21:22:34 --> 404 Page Not Found: Remote/login
ERROR - 2020-05-01 21:22:34 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-05-01 21:22:35 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-05-01 22:38:19 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-01 23:51:27 --> 404 Page Not Found: Muieblackcat/index
ERROR - 2020-05-01 23:51:29 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-01 23:51:32 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-05-01 23:51:33 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-05-01 23:51:34 --> 404 Page Not Found: MyAdmin/scripts
