<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-10 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-10 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-10 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-10 04:48:01 --> 404 Page Not Found: 0bef/index
ERROR - 2020-05-10 06:46:55 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-10 07:59:19 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-10 12:56:34 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-05-10 15:47:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-10 15:47:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-10 15:47:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-05-10 16:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-10 16:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-10 16:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-10 16:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-10 16:01:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-05-10 21:03:25 --> 404 Page Not Found: TP/public
ERROR - 2020-05-10 21:03:26 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-10 21:03:26 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-10 21:03:27 --> 404 Page Not Found: Html/public
ERROR - 2020-05-10 21:03:27 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-10 21:03:28 --> 404 Page Not Found: TP/html
ERROR - 2020-05-10 21:03:28 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-10 23:45:12 --> 404 Page Not Found: 0bef/index
