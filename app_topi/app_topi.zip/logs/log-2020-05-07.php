<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-07 00:14:24 --> 404 Page Not Found: 0bef/index
ERROR - 2020-05-07 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-07 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-07 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-07 02:40:05 --> 404 Page Not Found: Solr/index
ERROR - 2020-05-07 13:36:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-05-07 14:45:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-05-07 14:54:33 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-07 16:02:50 --> 404 Page Not Found: Console/index
ERROR - 2020-05-07 16:02:53 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-07 16:02:54 --> 404 Page Not Found: Loginaction/index
ERROR - 2020-05-07 16:02:54 --> 404 Page Not Found: Login/index
ERROR - 2020-05-07 16:02:55 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-07 16:02:57 --> 404 Page Not Found: Login/do_login
ERROR - 2020-05-07 20:37:44 --> 404 Page Not Found: ReportServer/index
