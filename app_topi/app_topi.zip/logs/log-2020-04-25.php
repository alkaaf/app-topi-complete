<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-25 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-04-25 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-04-25 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-04-25 03:01:55 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-25 03:01:56 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-25 03:01:58 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-25 03:01:59 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-25 03:41:59 --> 404 Page Not Found: Solr/index
ERROR - 2020-04-25 07:35:18 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-25 07:35:19 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-25 07:35:19 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-25 07:35:21 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-25 07:35:22 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-25 07:35:23 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-25 07:35:23 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-25 08:40:40 --> 404 Page Not Found: Webdav/index
ERROR - 2020-04-25 09:12:11 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-04-25 09:51:41 --> 404 Page Not Found: Runtime/Logs
ERROR - 2020-04-25 11:14:27 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-25 11:14:28 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-25 11:14:28 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-25 11:14:30 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-25 11:14:31 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-25 11:14:32 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-25 11:14:32 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-25 17:32:15 --> 404 Page Not Found: TP/public
ERROR - 2020-04-25 17:32:15 --> 404 Page Not Found: TP/index.php
ERROR - 2020-04-25 17:32:16 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-04-25 17:32:17 --> 404 Page Not Found: Html/public
ERROR - 2020-04-25 17:32:18 --> 404 Page Not Found: Public/index.php
ERROR - 2020-04-25 17:32:19 --> 404 Page Not Found: TP/html
ERROR - 2020-04-25 17:32:20 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-04-25 21:37:16 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-25 21:37:17 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-25 21:37:18 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-25 21:37:20 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-25 21:37:21 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-25 21:37:22 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-25 21:37:23 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-25 23:00:21 --> 404 Page Not Found: Hudson/index
ERROR - 2020-04-25 23:22:30 --> 404 Page Not Found: Muieblackcat/index
ERROR - 2020-04-25 23:22:32 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-04-25 23:22:36 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-04-25 23:22:37 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-04-25 23:22:39 --> 404 Page Not Found: MyAdmin/scripts
ERROR - 2020-04-25 23:22:41 --> 404 Page Not Found: Admin/scripts
