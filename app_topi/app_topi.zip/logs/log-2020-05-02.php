<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-02 01:04:46 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-02 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-02 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-02 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-02 02:55:00 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-02 03:30:58 --> 404 Page Not Found: Webadmin/index
ERROR - 2020-05-02 08:06:58 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-05-02 08:06:59 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-05-02 08:07:00 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-05-02 08:07:02 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-05-02 08:07:03 --> 404 Page Not Found: Remote/login
ERROR - 2020-05-02 08:07:04 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-05-02 08:07:05 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-05-02 09:19:14 --> 404 Page Not Found: HNAP1/index
ERROR - 2020-05-02 11:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-02 11:45:39 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-05-02 11:45:40 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-05-02 14:44:00 --> 404 Page Not Found: Ws_utc/config.do
ERROR - 2020-05-02 15:46:53 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-05-02 17:24:45 --> 404 Page Not Found: Runtime/log
ERROR - 2020-05-02 17:24:45 --> 404 Page Not Found: Web/kj
ERROR - 2020-05-02 21:55:54 --> 404 Page Not Found: HNAP1/index
ERROR - 2020-05-02 22:00:26 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-05-02 22:00:27 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-05-02 22:00:27 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-05-02 22:00:29 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-05-02 22:00:29 --> 404 Page Not Found: Remote/login
ERROR - 2020-05-02 22:00:30 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-05-02 22:00:31 --> 404 Page Not Found: HtmlV/welcomeMain.htm
