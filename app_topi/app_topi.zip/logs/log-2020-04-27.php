<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-27 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-04-27 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-04-27 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-04-27 06:22:53 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-04-27 06:22:57 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-04-27 06:22:58 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-04-27 06:23:00 --> 404 Page Not Found: MyAdmin/scripts
ERROR - 2020-04-27 08:43:21 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-27 08:43:22 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-27 08:43:23 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-27 08:43:25 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-27 08:43:26 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-27 08:43:27 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-27 08:43:27 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-27 09:30:07 --> 404 Page Not Found: Hudson/index
ERROR - 2020-04-27 10:18:24 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-27 10:18:25 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-27 10:18:25 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-27 10:18:26 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-27 10:18:26 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-27 10:18:26 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-27 10:18:27 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-27 11:36:53 --> 404 Page Not Found: Manager/text
ERROR - 2020-04-27 13:06:33 --> 404 Page Not Found: Titan/open
ERROR - 2020-04-27 13:06:33 --> 404 Page Not Found: Kj/config.js
ERROR - 2020-04-27 14:59:20 --> Severity: Notice --> Undefined variable: nik C:\xampp\htdocs\app_topi\controllers\api\Pendataan.php 131
ERROR - 2020-04-27 14:59:20 --> Severity: Notice --> Undefined variable: nik C:\xampp\htdocs\app_topi\controllers\api\Pendataan.php 132
ERROR - 2020-04-27 14:59:31 --> Severity: Notice --> Undefined variable: nik C:\xampp\htdocs\app_topi\controllers\api\Pendataan.php 131
ERROR - 2020-04-27 15:08:24 --> Severity: Notice --> Undefined variable: nik C:\xampp\htdocs\app_topi\controllers\api\Pendataan.php 198
ERROR - 2020-04-27 15:47:43 --> 404 Page Not Found: Muieblackcat/index
ERROR - 2020-04-27 15:47:45 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-04-27 15:47:48 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-04-27 15:47:50 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-04-27 15:47:52 --> 404 Page Not Found: MyAdmin/scripts
ERROR - 2020-04-27 16:06:09 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\app_topi\controllers\api\Pendataan.php 132
ERROR - 2020-04-27 17:32:03 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-27 17:32:03 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-27 17:32:04 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-27 17:32:05 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-27 17:32:05 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-27 17:32:06 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-27 17:32:06 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-27 21:14:52 --> 404 Page Not Found: Axis2/services
ERROR - 2020-04-27 22:13:03 --> 404 Page Not Found: Portal/redlion
