<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-05 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-05 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-05 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-05 01:45:27 --> 404 Page Not Found: Manager/html
ERROR - 2020-05-05 05:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-05 07:37:45 --> 404 Page Not Found: TP/public
ERROR - 2020-05-05 07:37:46 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-05 07:37:47 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-05 07:37:47 --> 404 Page Not Found: Html/public
ERROR - 2020-05-05 07:37:48 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-05 07:37:49 --> 404 Page Not Found: TP/html
ERROR - 2020-05-05 07:37:50 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-05 08:25:19 --> 404 Page Not Found: Goform/webLogin
ERROR - 2020-05-05 09:57:41 --> 404 Page Not Found: Newsphp/index
ERROR - 2020-05-05 12:29:36 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-05 12:29:40 --> 404 Page Not Found: Pma/scripts
ERROR - 2020-05-05 12:29:41 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-05-05 13:47:12 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-05 15:30:24 --> 404 Page Not Found: Console/index
ERROR - 2020-05-05 15:30:27 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-05 15:30:27 --> 404 Page Not Found: Loginaction/index
ERROR - 2020-05-05 15:30:28 --> 404 Page Not Found: Login/index
ERROR - 2020-05-05 15:30:29 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-05 15:30:30 --> 404 Page Not Found: Login/do_login
ERROR - 2020-05-05 20:37:34 --> 404 Page Not Found: Manager/html
ERROR - 2020-05-05 22:43:08 --> 404 Page Not Found: TP/public
ERROR - 2020-05-05 22:43:09 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-05 22:43:09 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-05 22:43:10 --> 404 Page Not Found: Html/public
ERROR - 2020-05-05 22:43:10 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-05 22:43:11 --> 404 Page Not Found: TP/html
ERROR - 2020-05-05 22:43:11 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-05 23:35:12 --> 404 Page Not Found: Portal/redlion
