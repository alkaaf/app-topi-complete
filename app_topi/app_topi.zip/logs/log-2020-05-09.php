<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-09 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-09 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-09 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-09 10:43:12 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-05-09 13:25:12 --> 404 Page Not Found: My/scripts
ERROR - 2020-05-09 13:25:42 --> 404 Page Not Found: MyAdmin/scripts
ERROR - 2020-05-09 14:59:25 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2020-05-09 18:14:09 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-09 19:03:20 --> 404 Page Not Found: Assets/theme
ERROR - 2020-05-09 19:03:42 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-09 20:49:18 --> 404 Page Not Found: TP/public
ERROR - 2020-05-09 20:49:18 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-09 20:49:19 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-09 20:49:19 --> 404 Page Not Found: Html/public
ERROR - 2020-05-09 20:49:20 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-09 20:49:20 --> 404 Page Not Found: TP/html
ERROR - 2020-05-09 20:49:21 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-09 21:24:14 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-09 22:49:52 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-09 22:59:40 --> 404 Page Not Found: Hudson/index
