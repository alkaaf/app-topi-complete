<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-24 00:11:55 --> 404 Page Not Found: Images/favicon_1.ico
ERROR - 2020-04-24 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-04-24 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-04-24 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-04-24 01:16:32 --> 404 Page Not Found: TP/public
ERROR - 2020-04-24 01:16:33 --> 404 Page Not Found: TP/index.php
ERROR - 2020-04-24 01:16:34 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-04-24 01:16:35 --> 404 Page Not Found: Html/public
ERROR - 2020-04-24 01:16:39 --> 404 Page Not Found: Public/index.php
ERROR - 2020-04-24 01:16:40 --> 404 Page Not Found: TP/html
ERROR - 2020-04-24 01:16:41 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-04-24 03:32:28 --> 404 Page Not Found: Solr/admin
ERROR - 2020-04-24 04:07:47 --> 404 Page Not Found: WSMAN/index
ERROR - 2020-04-24 07:20:57 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-04-24 08:55:24 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ',' or ';' C:\xampp\htdocs\app_topi\controllers\api\covid19.php 22
ERROR - 2020-04-24 09:00:03 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-24 09:00:04 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-24 09:00:08 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-24 09:00:09 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-24 10:27:50 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2020-04-24 12:28:33 --> 404 Page Not Found: Sdk/index
ERROR - 2020-04-24 12:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-24 12:28:33 --> 404 Page Not Found: Nmaplowercheck1587706121/index
ERROR - 2020-04-24 12:28:34 --> 404 Page Not Found: HNAP1/index
ERROR - 2020-04-24 12:28:49 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-04-24 12:29:01 --> 404 Page Not Found: Evox/about
ERROR - 2020-04-24 12:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-24 14:26:19 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-24 14:26:20 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-24 14:26:21 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-24 14:26:22 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-24 21:22:39 --> 404 Page Not Found: Hudson/index
ERROR - 2020-04-24 21:52:54 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-24 21:52:55 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-24 21:52:56 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-24 21:52:57 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-24 22:13:18 --> 404 Page Not Found: TP/public
ERROR - 2020-04-24 22:13:19 --> 404 Page Not Found: TP/index.php
ERROR - 2020-04-24 22:13:20 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-04-24 22:13:20 --> 404 Page Not Found: Html/public
ERROR - 2020-04-24 22:13:21 --> 404 Page Not Found: Public/index.php
ERROR - 2020-04-24 22:13:22 --> 404 Page Not Found: TP/html
ERROR - 2020-04-24 22:13:23 --> 404 Page Not Found: Elrektphp/index
