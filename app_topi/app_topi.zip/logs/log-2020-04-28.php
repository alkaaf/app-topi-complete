<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-28 00:02:44 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-28 00:02:45 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-28 00:02:45 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-28 00:02:47 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-28 00:02:48 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-28 00:02:48 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-28 00:02:49 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-28 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-04-28 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-04-28 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-04-28 01:19:13 --> 404 Page Not Found: TP/public
ERROR - 2020-04-28 01:19:15 --> 404 Page Not Found: TP/index.php
ERROR - 2020-04-28 01:19:16 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-04-28 01:19:17 --> 404 Page Not Found: Html/public
ERROR - 2020-04-28 01:19:18 --> 404 Page Not Found: Public/index.php
ERROR - 2020-04-28 01:19:20 --> 404 Page Not Found: TP/html
ERROR - 2020-04-28 01:19:21 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-04-28 01:43:55 --> 404 Page Not Found: Manager/html
ERROR - 2020-04-28 06:07:48 --> 404 Page Not Found: Axis2/services
ERROR - 2020-04-28 06:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-28 06:29:47 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-04-28 06:29:48 --> 404 Page Not Found: Well_known/security.txt
ERROR - 2020-04-28 11:11:33 --> 404 Page Not Found: Hudson/index
ERROR - 2020-04-28 18:27:01 --> 404 Page Not Found: Newsphp/index
ERROR - 2020-04-28 18:44:42 --> 404 Page Not Found: Newsphp/index
ERROR - 2020-04-28 20:50:29 --> 404 Page Not Found: Newsphp/index
