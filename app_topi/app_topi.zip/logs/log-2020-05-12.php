<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-12 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-12 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-12 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-12 01:44:12 --> 404 Page Not Found: Manager/html
ERROR - 2020-05-12 08:06:23 --> 404 Page Not Found: Manager/html
ERROR - 2020-05-12 08:29:56 --> 404 Page Not Found: Assets/theme
ERROR - 2020-05-12 08:31:49 --> 404 Page Not Found: LPn3/index
ERROR - 2020-05-12 11:40:18 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-12 12:07:13 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-12 13:38:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 14:47:57 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-12 21:36:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 21:36:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-05-12 21:36:34 --> 404 Page Not Found: Pelayanan/daftar
ERROR - 2020-05-12 21:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-12 21:46:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-12 21:46:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-05-12 23:33:37 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-12 23:38:15 --> 404 Page Not Found: api/Jsonws/invoke
