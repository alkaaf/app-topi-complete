<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-29 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-04-29 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-04-29 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-04-29 06:34:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 10:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-04-29 10:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-04-29 10:11:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 10:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-04-29 10:34:37 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-04-29 10:42:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-04-29 10:42:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-04-29 10:48:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-04-29 11:10:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-04-29 16:12:21 --> 404 Page Not Found: Manager/html
ERROR - 2020-04-29 18:12:50 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-29 18:12:50 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-29 18:12:51 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-29 18:12:53 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-29 18:12:53 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-29 18:12:54 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-29 18:12:54 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-29 19:35:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 19:35:56 --> 404 Page Not Found: Assets/uploads
ERROR - 2020-04-29 19:36:04 --> 404 Page Not Found: Assets/theme
ERROR - 2020-04-29 19:36:08 --> 404 Page Not Found: Assets/uploads
ERROR - 2020-04-29 19:36:09 --> 404 Page Not Found: Assets/theme
ERROR - 2020-04-29 19:37:15 --> 404 Page Not Found: Assets/uploads
ERROR - 2020-04-29 19:37:29 --> 404 Page Not Found: Assets/theme
ERROR - 2020-04-29 19:37:31 --> 404 Page Not Found: Assets/theme
ERROR - 2020-04-29 19:42:47 --> 404 Page Not Found: Assets/theme
ERROR - 2020-04-29 21:59:55 --> 404 Page Not Found: Hudson/index
ERROR - 2020-04-29 23:04:51 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-29 23:04:52 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-29 23:04:53 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-29 23:04:55 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-29 23:04:56 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-29 23:04:56 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-29 23:04:57 --> 404 Page Not Found: HtmlV/welcomeMain.htm
ERROR - 2020-04-29 23:32:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-29 23:38:12 --> 404 Page Not Found: Homeasp/index
ERROR - 2020-04-29 23:38:13 --> 404 Page Not Found: Logincgi/index
ERROR - 2020-04-29 23:38:14 --> 404 Page Not Found: Vpn/index.html
ERROR - 2020-04-29 23:38:17 --> 404 Page Not Found: Dana_na/auth
ERROR - 2020-04-29 23:38:18 --> 404 Page Not Found: Remote/login
ERROR - 2020-04-29 23:38:19 --> 404 Page Not Found: Indexasp/index
ERROR - 2020-04-29 23:38:20 --> 404 Page Not Found: HtmlV/welcomeMain.htm
