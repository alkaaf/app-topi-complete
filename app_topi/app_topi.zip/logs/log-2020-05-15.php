<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-15 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-15 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-15 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-15 02:07:42 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-15 06:30:13 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-15 08:18:04 --> 404 Page Not Found: api/Jsonws/invoke
