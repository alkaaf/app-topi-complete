<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-06 01:04:37 --> 404 Page Not Found: Console/index
ERROR - 2020-05-06 01:04:40 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-06 01:04:40 --> 404 Page Not Found: Loginaction/index
ERROR - 2020-05-06 01:04:41 --> 404 Page Not Found: Login/index
ERROR - 2020-05-06 01:04:42 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-06 01:04:44 --> 404 Page Not Found: Login/do_login
ERROR - 2020-05-06 01:05:16 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-06 01:05:16 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-06 01:05:16 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-06 03:55:00 --> 404 Page Not Found: Console/index
ERROR - 2020-05-06 03:55:03 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-06 03:55:04 --> 404 Page Not Found: Loginaction/index
ERROR - 2020-05-06 03:55:05 --> 404 Page Not Found: Login/index
ERROR - 2020-05-06 03:55:06 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-06 03:55:08 --> 404 Page Not Found: Login/do_login
ERROR - 2020-05-06 05:00:49 --> 404 Page Not Found: TP/public
ERROR - 2020-05-06 05:00:50 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-06 05:00:51 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-06 05:00:51 --> 404 Page Not Found: Html/public
ERROR - 2020-05-06 05:00:52 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-06 05:00:53 --> 404 Page Not Found: TP/html
ERROR - 2020-05-06 05:00:54 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-06 06:22:36 --> 404 Page Not Found: Console/index
ERROR - 2020-05-06 06:22:39 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-06 06:22:40 --> 404 Page Not Found: Loginaction/index
ERROR - 2020-05-06 06:22:40 --> 404 Page Not Found: Login/index
ERROR - 2020-05-06 06:22:41 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-06 06:22:43 --> 404 Page Not Found: Login/do_login
ERROR - 2020-05-06 06:26:33 --> 404 Page Not Found: Stager32/index
ERROR - 2020-05-06 06:26:34 --> 404 Page Not Found: Stager64/index
ERROR - 2020-05-06 08:27:23 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-06 10:27:58 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-06 13:48:54 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-06 15:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-06 18:19:52 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-06 18:20:06 --> 404 Page Not Found: Myadmin/scripts
ERROR - 2020-05-06 23:50:48 --> 404 Page Not Found: Portal/redlion
