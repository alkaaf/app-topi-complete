<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-14 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-14 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-14 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-14 13:25:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-05-14 13:31:21 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-14 14:47:41 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-05-14 15:00:38 --> 404 Page Not Found: Manager/html
ERROR - 2020-05-14 16:25:43 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-14 18:45:41 --> 404 Page Not Found: User/soapCaller.bs
ERROR - 2020-05-14 19:24:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-05-14 22:50:25 --> 404 Page Not Found: TP/public
ERROR - 2020-05-14 22:50:26 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-14 22:50:27 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-14 22:50:28 --> 404 Page Not Found: Html/public
ERROR - 2020-05-14 22:50:32 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-14 22:50:33 --> 404 Page Not Found: TP/html
ERROR - 2020-05-14 22:50:34 --> 404 Page Not Found: Elrektphp/index
