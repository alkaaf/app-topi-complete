<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-05-13 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-05-13 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-05-13 01:42:13 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-05-13 14:02:48 --> 404 Page Not Found: TP/public
ERROR - 2020-05-13 14:02:48 --> 404 Page Not Found: TP/index.php
ERROR - 2020-05-13 14:02:48 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-05-13 14:02:49 --> 404 Page Not Found: Html/public
ERROR - 2020-05-13 14:02:49 --> 404 Page Not Found: Public/index.php
ERROR - 2020-05-13 14:02:50 --> 404 Page Not Found: TP/html
ERROR - 2020-05-13 14:02:50 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-05-13 16:47:33 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-05-13 17:15:29 --> 404 Page Not Found: Hudson/index
ERROR - 2020-05-13 18:07:57 --> 404 Page Not Found: Ab2g/index
ERROR - 2020-05-13 20:36:41 --> 404 Page Not Found: Solr/admin
ERROR - 2020-05-13 21:47:02 --> 404 Page Not Found: api/Jsonws/invoke
ERROR - 2020-05-13 23:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-13 23:55:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-05-13 23:55:54 --> 404 Page Not Found: Well_known/security.txt
