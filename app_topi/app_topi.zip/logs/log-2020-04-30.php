<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-30 01:05:15 --> Severity: Notice --> Undefined index: HTTP_HOST C:\xampp\htdocs\app_topi\config\config.php 26
ERROR - 2020-04-30 01:05:15 --> Severity: Warning --> Use of undefined constant OCI_COMMIT_ON_SUCCESS - assumed 'OCI_COMMIT_ON_SUCCESS' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\base_system\database\DB.php 201
ERROR - 2020-04-30 01:05:15 --> Severity: error --> Exception: Call to undefined function oci_connect() C:\xampp\htdocs\base_system\database\drivers\oci8\oci8_driver.php 238
ERROR - 2020-04-30 01:40:00 --> 404 Page Not Found: 0bef/index
ERROR - 2020-04-30 10:40:51 --> 404 Page Not Found: Portal/redlion
ERROR - 2020-04-30 15:27:32 --> 404 Page Not Found: Images/favicon_1.ico
ERROR - 2020-04-30 20:38:32 --> 404 Page Not Found: ReportServer/index
ERROR - 2020-04-30 20:59:18 --> 404 Page Not Found: TP/public
ERROR - 2020-04-30 20:59:22 --> 404 Page Not Found: TP/index.php
ERROR - 2020-04-30 20:59:23 --> 404 Page Not Found: Thinkphp/html
ERROR - 2020-04-30 20:59:23 --> 404 Page Not Found: Html/public
ERROR - 2020-04-30 20:59:24 --> 404 Page Not Found: Public/index.php
ERROR - 2020-04-30 20:59:28 --> 404 Page Not Found: TP/html
ERROR - 2020-04-30 20:59:29 --> 404 Page Not Found: Elrektphp/index
ERROR - 2020-04-30 22:28:41 --> 404 Page Not Found: Hudson/index
