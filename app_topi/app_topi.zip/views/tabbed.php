<section class="content">
    <div class="nav-tabs-custom flat">
            <ul class="nav nav-tabs pull-right"">
              <li class="active"><a href="#blog" data-toggle="tab" aria-expanded="true"><?php echo $judul; ?></a></li>
              <li class="pull-left header"><i class="fa fa-th"></i><?php echo $judul; ?></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="blog">
                <?php echo $content; ?>
              </div><!-- /.tab-pane -->
            </div><!-- /.tab-content -->
          </div>
</section>