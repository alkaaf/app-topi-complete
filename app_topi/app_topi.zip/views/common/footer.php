
</div><!-- ./wrapper -->
<footer class="main-footer">
<div class="pull-right hidden-xs">
          <b>Version</b><a href="#"> 1.1 </a>
        </div>
       <strong>Copyright &copy; 2016 <a href="#">Dispenduk & Pencapil Kota Mojokerto</a>.</strong> All rights reserved.
</footer>

    <!-- jQuery 2.1.3 -->
  <!--script src="<?php echo base_url();?>assets/plugins/jQuery/jQuery-2.1.3.min.js"></script-->
    <!-- Bootstrap 3.3.2 JS -->
<!--link href="<?php echo base_url();?>assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/select2.css" rel="stylesheet" type="text/css" /-->
  
    <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>assets/xcrud/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

   <!-- Bootstrap WYSIHTML5 -->
   <!-- Morris.js charts -->
    <script src="<?php echo base_url();?>assets/plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="<?php echo base_url();?>assets/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <!-- jQuery Knob Chart -->
      <!-- Slimscroll -->
    <script src="<?php echo base_url();?>assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
   <!-- AdminLTE App -->
    <script src="<?php echo base_url();?>assets/dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  
   <!-- AdminLTE for demo purposes -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/select2.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/moment.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
  <!-- XCRUD -->
  
   <script> 
     
      

      function change_layout(cls) {
      $("body").toggleClass(cls);
      $.AdminLTE.layout.fixSidebar();  
    }
    </script>

   
  
  </body>
</html>
